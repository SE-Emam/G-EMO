
import json
from plugins import whatsapp_plugin, facebook_plugin, canva_plugin

def execute(cmd, config):
    plugin = cmd["plugin"]
    mode = config["plugins"].get(plugin, {}).get("mode", "human")
    if plugin == "whatsapp":
        return whatsapp_plugin.send(cmd["raw"], mode, config)
    if plugin == "facebook":
        return facebook_plugin.handle(cmd["raw"], mode, config)
    if plugin == "canva":
        return canva_plugin.create(cmd["raw"], mode)
    return "امر غير معروف"
