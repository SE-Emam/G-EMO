
def parse_command(text: str):
    text_low = text.lower()
    if "واتساب" in text_low or "whatsapp" in text_low:
        return {"plugin": "whatsapp", "action": "send", "raw": text}
    if "فيس" in text_low or "facebook" in text_low:
        return {"plugin": "facebook", "action": "monitor_or_post", "raw": text}
    if "كانفا" in text_low or "canva" in text_low:
        return {"plugin": "canva", "action": "create", "raw": text}
    if "تليجرام" in text_low:
        return {"plugin": "telegram", "action": "send", "raw": text}
    return {"plugin": "none", "raw": text}
