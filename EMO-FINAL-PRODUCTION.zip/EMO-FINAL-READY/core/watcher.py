
import uiautomator2 as u2, time
d = u2.connect()

def watch_loop(on_command):
    last = ""
    while True:
        try:
            # يراقب Gemini العادي
            boxes = d(className="android.widget.EditText")
            if boxes.exists:
                txt = boxes[-1].get_text()
                if txt and txt != last and len(txt) > 2:
                    last = txt
                    on_command(txt)
        except: pass
        time.sleep(2)
