[app]
title = EMO
package.name = emoagent
package.domain = com.emam.emo
source.dir = .
version = 1.0.0
requirements = python3,kivy,uiautomator2,requests
orientation = portrait
icon.filename = icon.png
android.permissions = INTERNET,FOREGROUND_SERVICE,BIND_ACCESSIBILITY_SERVICE,SYSTEM_ALERT_WINDOW,POST_NOTIFICATIONS
android.api = 33
android.minapi = 24
