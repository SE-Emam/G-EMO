
# Gemini Use Emo - Headless Service
# شغل: python app.py
# المتطلبات: pip install uiautomator2
# لازم تدي صلاحية وصول مرة واحدة

from service.background import *
