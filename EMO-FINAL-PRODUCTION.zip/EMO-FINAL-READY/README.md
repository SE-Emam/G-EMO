# Gemini Use Emo
Headless Agent - استخدم شات Gemini العادي كايجنت تحكم في الهاتف (بشري + API)
