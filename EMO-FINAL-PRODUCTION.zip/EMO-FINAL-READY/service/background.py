
from core.watcher import watch_loop
from core.brain import parse_command
from core.executor import execute
import json
config = json.load(open("/sdcard/Download/agent_config.json"))
def on_cmd(text):
    cmd = parse_command(text)
    res = execute(cmd, config)
    print(res)

watch_loop(on_cmd)
