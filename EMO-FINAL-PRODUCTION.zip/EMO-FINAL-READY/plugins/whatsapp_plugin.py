
import uiautomator2 as u2, time
def send(raw_text, mode, config):
    d = u2.connect()
    if mode == "human":
        d.app_start("com.whatsapp")
        time.sleep(2)
        # هنا يفتح بحث ويكتب - مبسط
        d(description="بحث").click()
        return f"تم فتح واتساب كبشري لتنفيذ: {raw_text}"
    else:
        return "ارسال API واتساب (يحتاج pywhatkit)"
