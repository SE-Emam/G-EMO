
import uiautomator2 as u2, time
def create(raw_text, mode):
    d = u2.connect()
    d.app_start("com.canva.editor")
    time.sleep(3)
    return f"فتحت كانفا كبشري: {raw_text}"
