
"""
EMO - Gemini Use Emo - Production Ready
Headless service - يستخدم شات Gemini العادي
"""

__version__ = "1.0.0"

import os, json, time
from core.watcher import watch_loop
from core.brain import parse_command
from core.executor import execute

CONFIG_PATH = "/sdcard/Download/emo_config.json"

def load_config():
    try:
        return json.load(open(CONFIG_PATH))
    except:
        return json.load(open("config/settings.json"))

def on_command(text):
    config = load_config()
    cmd = parse_command(text)
    result = execute(cmd, config)
    # اكتب النتيجة في اشعار او في Gemini
    print(f"[EMO] {text} -> {result}")

if __name__ == "__main__":
    print("EMO Production Service Started - بيراقب Gemini العادي...")
    watch_loop(on_command)
